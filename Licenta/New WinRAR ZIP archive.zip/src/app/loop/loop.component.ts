import { Component, OnInit } from '@angular/core';
import { DataService } from './../data.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Http, Headers, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/map';
import { DxTreeViewModule } from 'devextreme-angular';

@Component({
  selector: 'app-loop',
  templateUrl: './loop.component.html',
  styleUrls: ['./loop.component.css']
})
export class LoopComponent {
  loops: Array<any>;
  constructor(public dataService: DataService) {

  }
  getLoopSection(loopParam) {
		this.dataService.getLoop(loopParam).subscribe(
			(data: any) => {
				if (data) {
          this.loops = data;
          console.log(this.loops)
				}
			}, (err: any) => {
			console.log(err)
			});

	}

}

 
  // Define a users property to hold our user data
  // loops: Array<any>;

  //   // Create an instance of the DataService through dependency injection
  //   constructor(private _dataService: DataService) {

  //     // Access the Data Service's getUsers() method we defined
  //     // this._dataService.getLoop()
  //     //     .subscribe(res => this.loops = res);


  //   }
