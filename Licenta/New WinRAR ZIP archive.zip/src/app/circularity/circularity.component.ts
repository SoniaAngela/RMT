import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-circularity',
  templateUrl: './circularity.component.html',
  styleUrls: ['./circularity.component.css']
})
export class CircularityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
