import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { DataService } from './data.service';

import {Routes, RouterModule, Router} from "@angular/router";

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { LoopComponent } from './loop/loop.component';
import { CircularityComponent } from './circularity/circularity.component';
import { HttpClientModule} from '@angular/common/http';
import { ROUTES } from './app.routes';
import { DxButtonModule, DxTreeViewModule } from 'devextreme-angular';
import { DxTextBoxModule } from 'devextreme-angular';
import { DataListComponent } from './data-list/data-list.component';
import 'devextreme/integration/jquery';
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    LoopComponent,
    CircularityComponent,
    DataListComponent
   
  ],
  imports: [
    BrowserModule,
    HttpModule,              // <-Add HttpModule
    HttpClientModule,
    FormsModule,
    DxButtonModule,
    DxTreeViewModule,
    DxTextBoxModule,
    RouterModule.forRoot(ROUTES, {useHash: false}),
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
